from flask import Flask, request, render_template_string

app = Flask(__name__)


@app.after_request
def set_csp(response):
    # CSP Specification: https://www.w3.org/TR/CSP3/
    # Content Security Policy (CSP) is an HTTP response header that restricts which resources a browser can load or execute.
    # Here, resources are denied by default but for the case of 'style' inline style and 'self' are allowed. 
    # 'self' directive allows resources which are same-origin with the document itself.

    response.headers["Content-Security-Policy"] = (
        "default-src 'none'; "
        "script-src 'none'; "
        "style-src 'self' 'unsafe-inline'; "
        "object-src 'none'; "
        "base-uri 'none'; "
        "frame-ancestors 'none'; "
        "frame-src 'none'; "

        # This might be a good idea for exfiltration ;)
        "img-src *; "
    )

    return response

INDEX = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Alpaca Customs</title>
    <link rel="stylesheet" href="{{ url_for('static', filename='style.css') }}">
    <style>
        {{ artwork | safe }}
    </style>
</head>
<body>
    <div class="artwork-container">
        <div class="plaque plaque-top">
            <span class="flag" data-flag="{{ flag }}">Flag: {{ flag }}</span> 
        </div>
        <div class="frame">
            <div class="canvas">
                <!-- sky & sun -->
                <div class="sky"></div> <div class="sun"></div> <div class="cloud cloud1"></div> <div class="cloud cloud2"></div>
                <!-- mountains -->
                <div class="mountains"> <div class="mountain mountain-back"></div> <div class="mountain mountain-mid"></div> <div class="mountain mountain-front"></div> </div>
                <!-- forest trees -->
                <div class="forest"> <div class="tree tree1"></div> <div class="tree tree2"></div> <div class="tree tree3"></div> <div class="tree tree4"></div> <div class="tree tree5"></div> <div class="tree tree6"></div> <div class="tree tree7"></div> <div class="tree tree8"></div> <div class="tree tree9"></div> <div class="tree tree10"></div> </div>
                <!-- ground and grass -->
                <div class="ground"></div> <div class="grass-blade" style="left:8%;"></div> <div class="grass-blade" style="left:12%;"></div> <div class="grass-blade" style="left:85%;"></div> <div class="grass-blade" style="left:89%;"></div> <div class="grass-blade" style="left:20%;"></div> <div class="grass-blade" style="left:75%;"></div>

                <!-- AlpacaHack sign -->
                <div class="hacker-sign"> <div class="sign-board"> <span class="sign-text">AlpacaHack</span> </div> <div class="sign-post"></div> </div>

                <!-- ALPACA -->
                <div class="alpaca">
                    <!-- back legs -->
                    <div class="leg leg-back-left"></div> <div class="leg leg-back-right"></div> <div class="hoof hoof-bl"></div> <div class="hoof hoof-br"></div>
                    <!-- body -->
                    <div class="body"></div>
                    <!-- neck and neck wool -->
                    <div class="neck"></div> <div class="neck-wool"></div>
                    <!-- ears -->
                    <div class="ear ear-left"> <div class="ear-inner"></div> </div> <div class="ear ear-right"> <div class="ear-inner"></div> </div>
                    <!-- head tufts -->
                    <div class="head-tuft ht1"></div> <div class="head-tuft ht2"></div> <div class="head-tuft ht3"></div>
                    <!-- head -->
                    <div class="head"></div>
                    <!-- eyes and sparkles -->
                    <div class="eye eye-left"></div> <div class="eye eye-right"></div> <div class="eye-sparkle es1"></div> <div class="eye-sparkle es2"></div>
                    <!-- blush -->
                    <div class="blush blush-left"></div> <div class="blush blush-right"></div>
                    <!-- snout, nose, mouth -->
                    <div class="snout"></div> <div class="nose"></div> <div class="mouth"></div>
                    <!-- front legs -->
                    <div class="leg leg-front-left"></div> <div class="leg leg-front-right"></div> <div class="hoof hoof-fl"></div> <div class="hoof hoof-fr"></div>
                </div>
            </div>

            <!-- Artist & Title Plaque -->
            <div class="plaque  plaque-bottom">
                <span class="title">{{ title }}</span>
                <span class="artist">{{ artist }}</span>
            </div>
        </div>
    </div>
</body>
</html>
""".strip()


@app.get("/")
def index():
    artist = request.args.get("artist", "bubu")
    title = request.args.get("title", "my best friend")
    artwork = request.args.get("artwork", "\n".join(open("./static/example.css").readlines()))
    # Flag format: Alpaca{[A-Z]{1,6}}
    flag = request.cookies.get("FLAG", "Alpaca{DUMMY}")
    return render_template_string(INDEX, artist=artist, title=title, artwork=artwork, flag=flag)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=3000)
